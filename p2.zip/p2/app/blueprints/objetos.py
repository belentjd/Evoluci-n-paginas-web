from flask import Blueprint, render_template, abort, g, request, redirect, url_for, current_app
import os
from werkzeug.utils import secure_filename
from functools import wraps

objetos_bp = Blueprint("objetos", __name__,  url_prefix="/objetos")

objetos = [
    {
        "id": 1,
        "nombre": "Mochila azul",
        "descripcion": "Color azul oscuro, marca Nike, con apuntes dentro.",
        "fecha": "10/10/2025",
        "lugar": "Biblioteca",
        "imagen": "mochila.jpg"
    },
    {
        "id": 2,
        "nombre": "Llaves",
        "descripcion": "Un poco oxidadas, encontradas junto a su llavero.",
        "fecha": "08/10/2025",
        "lugar": "Cafetería",
        "imagen": "llaves.jpg"
    }
]


def load_objeto(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        objeto_id = request.view_args.get("objeto_id")
        objeto = next((o for o in objetos if o["id"] == int(objeto_id)), None)
        if objeto is None:
            abort(404)
        kwargs["objeto"] = objeto
        return f(*args, **kwargs)
    return decorated_function


@objetos_bp.route("/")
def list_objetos():

    nombre_filtro = request.args.get("nombre")
    lugar_filtro = request.args.get("lugar")

    objetos_filtrados = objetos

    if nombre_filtro:
        objetos_filtrados = [
            o for o in objetos_filtrados
            if nombre_filtro.lower() in o["nombre"].lower()
        ]

    if lugar_filtro:
        objetos_filtrados = [
            o for o in objetos_filtrados
            if lugar_filtro.lower() in o["lugar"].lower()
        ]

    return render_template("objetos/list.html", objetos=objetos_filtrados)

def get_objeto(objeto_id):
    objeto = next((o for o in objetos if o["id"] == int(objeto_id)), None)
    if objeto is None:
        abort(404)
    return objeto

@objetos_bp.route("/new")
def new_objeto():
    return render_template("objetos/new.html")

@objetos_bp.route("/<int:objeto_id>/edit")
@load_objeto
def edit_objeto(objeto_id, objeto):
    return render_template("objetos/edit.html", objeto=objeto)

@objetos_bp.route("/<int:objeto_id>")
@load_objeto
def show_objeto(objeto_id, objeto):
    return render_template("objetos/show.html", objeto=objeto)

@objetos_bp.route("/", methods= ['POST'])
def create_objeto():
    nuevo_id = max([o["id"] for o in objetos]) + 1 if objetos else 1

    nombre = request.form.get("nombre")
    descripcion = request.form.get("descripcion")
    fecha = request.form.get("fecha")
    lugar = request.form.get("lugar")

    archivo = request.files.get("imagen")
    nombre_archivo = "default.jpg"

    if archivo and archivo.filename != "":
        nombre_archivo = secure_filename(archivo.filename)
        ruta_guardado = os.path.join(current_app.root_path, "static", "img", nombre_archivo)
        archivo.save(ruta_guardado)

    nuevo_objeto = {
        "id": nuevo_id,
        "nombre": nombre,
        "descripcion": descripcion,
        "fecha": fecha,
        "lugar": lugar,
        "imagen": nombre_archivo
    }

    objetos.append(nuevo_objeto)

    return redirect(url_for("objetos.list_objetos"))

@objetos_bp.route("/<int:objeto_id>/edit", methods=["POST"])
def update_objeto(objeto_id):
    objeto = get_objeto(objeto_id)

    objeto["nombre"] = request.form.get("nombre")
    objeto["descripcion"] = request.form.get("descripcion")
    objeto["fecha"] = request.form.get("fecha")
    objeto["lugar"] = request.form.get("lugar")

    archivo = request.files.get("imagen")

    if archivo and archivo.filename != "":
        nombre_archivo = secure_filename(archivo.filename)
        ruta_guardado = os.path.join(current_app.root_path, "static", "img", nombre_archivo)
        archivo.save(ruta_guardado)
        objeto["imagen"] = nombre_archivo

    return redirect(url_for("objetos.list_objetos"))

@objetos_bp.route("/<int:objeto_id>", methods=["DELETE"])
@load_objeto
def delete_objeto(objeto_id, objeto):
    objetos.remove(objeto)
    return redirect(url_for("objetos.list_objetos"))


