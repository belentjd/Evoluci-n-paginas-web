from flask import Flask, render_template
from methodOverride import MethodOverrideMiddleware

from blueprints.objetos import objetos_bp
from blueprints.usuarios import usuarios_bp



app = Flask(__name__)

app.register_blueprint(objetos_bp)
app.register_blueprint(usuarios_bp)
app.wsgi_app = MethodOverrideMiddleware(app.wsgi_app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.errorhandler(404)
def error_404(error):
    return render_template("error404.html"), 404


@app.errorhandler(500)
def error_500(error):
    return render_template("error500.html"), 500

