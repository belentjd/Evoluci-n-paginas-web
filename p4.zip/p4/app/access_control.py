from flask import session, redirect, request, abort
from functools import wraps

def check_session(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('user') is None:
            return redirect('/auth/login')
        return f(*args, **kwargs)
    return decorated_function

# Permisos por rol
permissions = {
    "admin": [
        "objetos.list_objetos",
        "objetos.new_objeto",
        "objetos.create_objeto",
        "objetos.show_objeto",
        "objetos.edit_objeto",
        "objetos.update_objeto",
        "objetos.delete_objeto",
        "usuarios.list_usuarios",
        "usuarios.new_usuario",
        "usuarios.create_usuario",
        "usuarios.show_usuario",
        "usuarios.edit_usuario",
        "usuarios.update_usuario",
        "usuarios.delete_usuario"
    ],
    "user": [
        "objetos.list_objetos",
        "objetos.new_objeto",
        "objetos.create_objeto",
        "objetos.show_objeto",
        "objetos.edit_objeto",
        "objetos.update_objeto",
        "objetos.delete_objeto"
    ]
}

def check_role(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        endpoint = request.endpoint
        role = session["user"]["role"]

        if endpoint not in permissions[role]:
            abort(403)

        return f(*args, **kwargs)
    return decorated_function