from flask import Blueprint, render_template, abort, request, redirect, url_for, flash, session
from handle_files import save_file, delete_file
from functools import wraps
from models import Objeto  
from database import db
from access_control import check_session, check_role

objetos_bp = Blueprint("objetos", __name__,  url_prefix="/objetos")

def load_objeto(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        objetoId = request.view_args.get('objeto_id')
        user_id = session['user']['id']
        role = session['user']['role']
        
        if objetoId is not None:
            query = Objeto.query.filter_by(id=objetoId)
            if role != 'admin':
                query = query.filter_by(user_id=user_id)
            objeto = query.first()
            if objeto is None:
                abort(404)
            kwargs['objeto'] = objeto

        return f(*args, **kwargs)

    return decorated_function

@objetos_bp.route("/")
def list_objetos():
    nombre_filtro = request.args.get("nombre")
    lugar_filtro = request.args.get("lugar")

    query = Objeto.query   

    if nombre_filtro:
        query = query.filter(Objeto.nombre.ilike(f"%{nombre_filtro}%")) #para que no distinga entre mayúsculas y minúsculas

    if lugar_filtro:
        query = query.filter(Objeto.lugar.ilike(f"%{lugar_filtro}%"))
    
    user_id = session['user']['id']
    role = session['user']['role']
    if role != 'admin':
        query = query.filter(Objeto.user_id == user_id) #admin ve todos los objetos y user solo los suyos

    objetos = query.all()    
    
    return render_template("objetos/list.html", objetos=objetos)

@objetos_bp.route("/", methods=['POST'])
@save_file
def create_objeto(filename):

    nombre = request.form.get("nombre")
    lugar = request.form.get("lugar")
    descripcion = request.form.get("descripcion")
    fecha = request.form.get("fecha")

    # VALIDACIONES DE FORMULARIO
    if any(char in "(,/,=)" for char in nombre):
        flash("Error: El nombre contiene caracteres no permitidos como ( , / o =", "error")
        return redirect(url_for("objetos.new_objeto"))
    
    if len(lugar) < 3:
        flash("Error: El lugar debe ser más descriptivo (mínimo 3 letras)", "error")
        return redirect(url_for("objetos.new_objeto"))

    nuevo_objeto = Objeto(
    nombre=nombre,
    descripcion=descripcion,
    fecha=fecha,
    lugar=lugar,
    filename=filename,
    user_id=session['user']['id']
)

    db.session.add(nuevo_objeto)
    db.session.commit()

    flash("Objeto creado con éxito", "success")
    return redirect(url_for("objetos.list_objetos"))

def get_objeto(objeto_id):
    objeto = Objeto.query.get_or_404(objeto_id)
    return objeto

@objetos_bp.route("/new")
def new_objeto():
    return render_template("objetos/new.html")

@objetos_bp.route("/<int:objeto_id>/edit", methods=["GET"])
@load_objeto
def edit_objeto(objeto_id, objeto):
    # Esta es la que busca url_for('objetos.edit_objeto') en el listado
    return render_template("objetos/edit.html", objeto=objeto)

@objetos_bp.route("/<int:objeto_id>/edit", methods=["POST"])
@load_objeto
@save_file
def update_objeto(objeto_id, objeto, filename):

    objeto.nombre = request.form["nombre"]
    objeto.descripcion = request.form["descripcion"]
    objeto.fecha = request.form["fecha"]
    objeto.lugar = request.form["lugar"]
    if filename: 
        objeto.filename= filename

    db.session.commit()

    flash("Objeto editado correctamente", "success")
    return redirect(url_for("objetos.list_objetos"))

@objetos_bp.route("/<int:objeto_id>", methods=["GET"])
@load_objeto
def show_objeto(objeto_id, objeto):
    return render_template("objetos/show.html", objeto=objeto)

@objetos_bp.route("/<int:objeto_id>", methods=["DELETE"])
@load_objeto
@delete_file
def delete_objeto(objeto_id, objeto):

    db.session.delete(objeto)
    db.session.commit()

    flash("Objeto borrado correctamente", "success")
    return redirect(url_for("objetos.list_objetos"))


@objetos_bp.before_request
@check_session
def before_request_objetos():
    pass