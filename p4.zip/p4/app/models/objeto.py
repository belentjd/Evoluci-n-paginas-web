from database import db # Importamos el objeto db de la base de datos inicializado en app
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Enum

class Objeto(db.Model):
    __tablename__ = 'objeto'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(255), nullable=False)
    descripcion = db.Column(db.String(255), nullable=False)
    fecha = db.Column(db.Date, nullable=False)
    lugar = db.Column(db.String(255), nullable=False)
    filename = db.Column(db.String(120), nullable=True, unique=True)

    user_id = db.Column(db.String(36), db.ForeignKey('usuario.id'), nullable=False)

class Usuario(db.Model):
    __tablename__ = 'usuario'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False) #contraseña en hash
    role = db.Column(Enum("admin", "user", name="role_enum"), default='user', nullable=False) #enumerado: admin, user 

    def set_password(self, password):
        """Genera el hash de la contraseña y lo almacena."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Verifica si la contraseña ingresada es correcta."""
        return check_password_hash(self.password_hash, password)