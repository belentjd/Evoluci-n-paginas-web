from flask import Flask, render_template, send_from_directory
from methodOverride import MethodOverrideMiddleware
import os
from blueprints.objetos import objetos_bp
from blueprints.usuarios import usuarios_bp



app = Flask(__name__, static_folder='public', template_folder='templates')

app.register_blueprint(objetos_bp)
app.register_blueprint(usuarios_bp)
app.wsgi_app = MethodOverrideMiddleware(app.wsgi_app)

##### Configure flash key
app.secret_key = '1234'

##### Configure file uploads
app.config['UPLOAD_FOLDER'] = 'app/assets/images'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.errorhandler(404)
def error_404(error):
    return render_template("error404.html"), 404

@app.errorhandler(500)
def error_500(error):
    return render_template("error500.html"), 500

@app.route('/assets/images/<filename>')
def media_images(filename):
    return send_from_directory(os.path.join(app.root_path, 'assets', 'images'), filename)