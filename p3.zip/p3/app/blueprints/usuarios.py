from flask import Blueprint, render_template, request, redirect, url_for, abort
from functools import wraps


usuarios_bp = Blueprint(
    "usuarios",
    __name__,
    url_prefix="/usuarios"
)

usuarios = []
next_id = 1

def load_usuario(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):

        usuarioId = request.view_args.get('id')

        if usuarioId is not None:
            usuario_requested = next((u for u in usuarios if u['id'] == int(usuarioId)), None)

            if usuario_requested is None:
                abort(404)

            kwargs['usuario'] = usuario_requested

        return f(*args, **kwargs)

    return decorated_function

def get_usuario(id):
    usuario = next((o for o in usuarios if o["id"] == int(id)), None)
    if usuario is None:
        abort(404)
    return usuario

@usuarios_bp.route("/")
def list_usuarios():
    return render_template("usuarios/list.html", usuarios=usuarios)


@usuarios_bp.route("/new")
def new_usuario():
    return render_template("usuarios/new.html")


@usuarios_bp.route("/", methods=["POST"])
def create_usuario():
    global next_id

    usuario = {
        "id": next_id,
        "username": request.form["username"],
        "email": request.form["email"],
        "password": request.form["password"]
    }

    usuarios.append(usuario)
    next_id += 1

    return redirect(url_for("usuarios.list_usuarios"))

@usuarios_bp.route("/<int:id>")
@load_usuario
def show_usuario(id, usuario):
    return render_template("usuarios/show.html", usuario=usuario)

@usuarios_bp.route("/<int:id>/edit")
@load_usuario
def edit_usuario(id, usuario):
    return render_template("usuarios/edit.html", usuario=usuario)

@usuarios_bp.route("/<int:id>", methods=["POST"])
def update_usuario(id):
    usuario = get_usuario(id)
    usuario["username"] = request.form["username"]
    usuario["email"] = request.form["email"]
    usuario["password"] = request.form["password"]

    return redirect(url_for("usuarios.list_usuarios"))

@usuarios_bp.route("/<int:id>", methods=["DELETE"])
@load_usuario
def delete_usuario(id, usuario):
    usuarios.remove(usuario)

    return redirect(url_for("usuarios.list_usuarios"))

