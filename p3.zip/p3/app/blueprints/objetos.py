from flask import Blueprint, render_template, abort, request, redirect, url_for, flash
from handle_files import save_file, delete_file
from functools import wraps

objetos_bp = Blueprint("objetos", __name__,  url_prefix="/objetos")

objetos = [
    {
        "id": 1,
        "nombre": "Mochila azul",
        "descripcion": "Color azul oscuro, marca Nike, con apuntes dentro.",
        "fecha": "10/10/2025",
        "lugar": "Biblioteca",
        "imagen": "mochila.jpg"
    },
    {
        "id": 2,
        "nombre": "Llaves",
        "descripcion": "Un poco oxidadas, encontradas junto a su llavero.",
        "fecha": "08/10/2025",
        "lugar": "Cafetería",
        "imagen": "llaves.jpg"
    }
]

def load_objeto(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        objeto_id = kwargs.get("objeto_id") 
        objeto = next((o for o in objetos if o["id"] == int(objeto_id)), None)
        if objeto is None:
            abort(404)  
        kwargs["objeto"] = objeto
        return f(*args, **kwargs)
    return decorated_function

@objetos_bp.route("/")
def list_objetos():

    nombre_filtro = request.args.get("nombre")
    lugar_filtro = request.args.get("lugar")

    objetos_filtrados = objetos

    if nombre_filtro:
        objetos_filtrados = [
            o for o in objetos_filtrados
            if nombre_filtro.lower() in o["nombre"].lower()
        ]

    if lugar_filtro:
        objetos_filtrados = [
            o for o in objetos_filtrados
            if lugar_filtro.lower() in o["lugar"].lower()
        ]

    return render_template("objetos/list.html", objetos=objetos_filtrados)

@objetos_bp.route("/", methods=['POST'])
@save_file
def create_objeto(filename):
    nombre = request.form.get("nombre")
    lugar = request.form.get("lugar")

    # VALIDACIONES DE FORMULARIO (Punto 2 de la práctica)
    if any(char in "(,/,=)" for char in nombre):
        flash("Error: El nombre contiene caracteres no permitidos como ( , / o =", "error")
        return redirect(url_for("objetos.new_objeto"))
    
    if len(lugar) < 3:
        flash("Error: El lugar debe ser más descriptivo (mínimo 3 letras)", "error")
        return redirect(url_for("objetos.new_objeto"))

    nuevo_id = max([o["id"] for o in objetos]) + 1 if objetos else 1
    nuevo_objeto = {
        "id": nuevo_id,
        "nombre": nombre,
        "descripcion": request.form.get("descripcion"),
        "fecha": request.form.get("fecha"),
        "lugar": lugar,
        "imagen": filename or "default.jpg"
    }

    objetos.append(nuevo_objeto)
    flash("Objeto creado con éxito", "success")
    return redirect(url_for("objetos.list_objetos"))

def get_objeto(objeto_id):
    objeto = next((o for o in objetos if o["id"] == int(objeto_id)), None)
    if objeto is None:
        abort(404)
    return objeto

@objetos_bp.route("/new")
def new_objeto():
    return render_template("objetos/new.html")

@objetos_bp.route("/<int:objeto_id>/edit", methods=["GET"])
@load_objeto
def edit_objeto(objeto_id, objeto):
    # Esta es la que busca url_for('objetos.edit_objeto') en el listado
    return render_template("objetos/edit.html", objeto=objeto)

@objetos_bp.route("/<int:objeto_id>/edit", methods=["POST"])
@load_objeto
@save_file
def update_objeto(objeto_id, objeto, filename):
    objeto["nombre"] = request.form.get("nombre")
    objeto["descripcion"] = request.form.get("descripcion")
    objeto["fecha"] = request.form.get("fecha")
    objeto["lugar"] = request.form.get("lugar")

    if filename: 
        objeto["imagen"] = filename

    flash("Objeto editado correctamente", "success")
    return redirect(url_for("objetos.list_objetos"))

@objetos_bp.route("/<int:objeto_id>", methods=["GET"])
@load_objeto
def show_objeto(objeto_id, objeto):
    return render_template("objetos/show.html", objeto=objeto)

@objetos_bp.route("/<int:objeto_id>", methods=["DELETE"])
@load_objeto
@delete_file
def delete_objeto(objeto_id, objeto):
    objetos.remove(objeto)
    flash("Objeto borrado correctamente", "success")
    return redirect(url_for("objetos.list_objetos"))